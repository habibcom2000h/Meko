@echo off
set DIR=%~dp0
echo This project is configured for cloud/Linux builds with gradlew.
java -Dorg.gradle.appname=gradlew -classpath "%DIR%gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
