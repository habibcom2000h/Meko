# Meko

Meko is a Flutter starter for a social voice-room application.

## Build
Use Codemagic with the `meko-android` workflow.

The current build is a working UI/demo. Real authentication, database, live voice, chat, notifications, moderation, and payments require backend/services and will be added separately.
