package com.example.voicesocial

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class Room(val title:String, val users:Int, val host:String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MekoApp() }
    }
}

@Composable
fun MekoApp() {
    var tab by remember { mutableIntStateOf(0) }
    var showCreate by remember { mutableStateOf(false) }
    val rooms = remember {
        mutableStateListOf(
            Room("غرفة الأصدقاء", 128, "Meko Host"),
            Room("سهرانين الليلة", 76, "VIP"),
            Room("تعرف على ناس جدد", 54, "Live"),
            Room("الموسيقى والضحك", 31, "Host")
        )
    }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Meko", fontWeight = FontWeight.Bold) }) },
            bottomBar = {
                NavigationBar {
                    listOf("الرئيسية","الغرف","الأصدقاء","حسابي").forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Text(if (i == 0) "⌂" else if (i == 1) "◉" else if (i == 2) "♡" else "●") },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { pad ->
            when (tab) {
                0 -> Home(rooms, { showCreate = true }, Modifier.padding(pad))
                1 -> Rooms(rooms, Modifier.padding(pad))
                2 -> CenterPage("الأصدقاء", "قريباً: البحث والإضافة والمحادثات", Modifier.padding(pad))
                else -> Profile(Modifier.padding(pad))
            }
        }

        if (showCreate) {
            AlertDialog(
                onDismissRequest = { showCreate = false },
                title = { Text("إنشاء غرفة") },
                text = { Text("سيتم ربط إنشاء الغرف بالخادم والصوت المباشر في مرحلة Backend.") },
                confirmButton = { Button(onClick = { showCreate = false }) { Text("حسنًا") } }
            )
        }
    }
}

@Composable
fun Home(rooms: List<Room>, create: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("مرحباً في Meko 👋", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("تحدث، تعرّف على أشخاص جدد، وانضم إلى الغرف الصوتية.")
        Spacer(Modifier.height(18.dp))
        Button(onClick = create, modifier = Modifier.fillMaxWidth()) { Text("＋ إنشاء غرفة صوتية") }
        Spacer(Modifier.height(18.dp))
        Text("الغرف النشطة", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        RoomList(rooms)
    }
}

@Composable
fun Rooms(rooms: List<Room>, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("الغرف الصوتية", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        RoomList(rooms)
    }
}

@Composable
fun RoomList(rooms: List<Room>) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(rooms) { room ->
            Card(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(room.title, fontWeight = FontWeight.Bold)
                        Text("${room.users} مستخدم • ${room.host}")
                    }
                    Button(onClick = {}) { Text("دخول") }
                }
            }
        }
    }
}

@Composable
fun Profile(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("حسابي", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("الاسم: مستخدم Meko")
        Text("ID: 100001")
        Spacer(Modifier.height(16.dp))
        Text("🪙 العملات: 0")
        Text("🎁 الهدايا: 0")
        Text("⭐ المستوى: 1")
    }
}

@Composable
fun CenterPage(title: String, subtitle: String, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(subtitle)
        }
    }
}
